import * as util from "../../util/argon.js"

export const addPerson = async(SQLClient, {firstName, lastName, email, phoneNumber, password, birthday, hasCarLicence, hasMotorbikeLicence}) =>{
  const hashedPassword = await util.hash(password)
  const {rows} = await SQLClient.query(
    `INSERT INTO person (first_name, last_name, email, phone_number, password, birthday, has_car_licence, has_motorbike_licence)
      VALUES ($1, $2, $3, $4, $5, $6, $7, $8) RETURNING id`,
    [
      firstName,
      lastName,
      email,
      phoneNumber,
      hashedPassword,
      birthday,
      hasCarLicence,
      hasMotorbikeLicence
    ]);
  return rows[0]?.id;
}

export const getPersonByReferralCode = async(SQLClient, referralCode) =>{
  const {rows} = await SQLClient.query(`SELECT id FROM person WHERE referral_code = $1`, [referralCode]);
  if(rows[0]?.id !== undefined) {
    return rows[0].id;
  }
  throw new Error(`No user found for referral code: ${referralCode}`);
}

export const getPersonByEmail = async(SQLClient, email) =>{
  const {rows} = await SQLClient.query(`SELECT id, password, email, role FROM person WHERE email = $1`, [email]);
  return rows[0];
}


export const getPersonById = async(SQLClient,id) => {
  const {rows} = await SQLClient.query(`SELECT first_name, last_name, email, phone_number, birthday, has_car_licence, has_motorbike_licence FROM person WHERE id = $1`, [id]);
  return rows[0];
}

export const getProfileInfosById = async(SQLClient, id) =>{
  const {rows} = await SQLClient.query(`SELECT first_name, last_name, balance, referral_code FROM person WHERE id = $1`, [id]);
  return rows[0];
}

export const getAllPersons = async(SQLClient, {iPage}, {column}) => {
  const validColumnsQuery = `
    SELECT column_name
    FROM information_schema.columns
    WHERE table_name = 'person'
  `;

  const validColumnsResult = await SQLClient.query(validColumnsQuery);
  const validColumns = validColumnsResult.rows.map(row => row.column_name);

  if (!validColumns.includes(column)) {
    throw new Error('Invalid column name');
  }

  const {rows} = await SQLClient.query(`
    WITH person_page AS (
      SELECT id, first_name, last_name, email, phone_number, birthday, role, balance, has_car_licence, has_motorbike_licence, referral_code FROM person
      ORDER BY ${column} LIMIT 10 OFFSET ($1 - 1) * 10)
    SELECT * FROM person_page`, [iPage]);
  return rows;
}

export const personsCount = async(SQLClient) => {
  const {rows} = await SQLClient.query(`SELECT COUNT(*) FROM person`);
  return rows[0]?.count;
}

export const getSearchPersons = async(SQLClient, {iPage}, {value}, {column}) => {
  const validColumnsQuery = `
    SELECT column_name
    FROM information_schema.columns
    WHERE table_name = 'person'
  `;

  const validColumnsResult = await SQLClient.query(validColumnsQuery);
  const validColumns = validColumnsResult.rows.map(row => row.column_name);

  if (!validColumns.includes(column)) {
    throw new Error('Invalid column name');
  }

  const {rows} = await SQLClient.query(`
    WITH person_page AS (
      SELECT id, first_name, last_name, email, phone_number, role, balance, birthday, has_car_licence, has_motorbike_licence, referral_code FROM person
      WHERE (first_name ILIKE '%'||$2||'%' OR last_name ILIKE '%'||$2||'%')
      ORDER BY ${column} LIMIT 10 OFFSET ($1 - 1) * 10)
    SELECT * FROM person_page`, [iPage, value]);
  return rows;
}

export const personsSearchCount = async(SQLClient, {value}) => {
  const {rows} = await SQLClient.query(`SELECT COUNT(*) FROM person WHERE (first_name ILIKE '%'||$1||'%' OR last_name ILIKE '%'||$1||'%')`, [value]);
  return rows[0]?.count;
}

export const updateMySelf = async(SQLClient, {id, firstName, lastName, email, phoneNumber, password, hasCarLicence, hasMotorbikeLicence}) => {
  let query = `UPDATE person SET `;
  const querySet = [];
  const queryValues = [];
  if (firstName) {
      queryValues.push(firstName);
      querySet.push(`first_name = $${queryValues.length}`);
  }
  if (lastName){
      queryValues.push(lastName);
      querySet.push(`last_name = $${queryValues.length}`)
  }
  if (email){
      queryValues.push(email);
      querySet.push(`email = $${queryValues.length}`)
  }
  if (phoneNumber){
      queryValues.push(phoneNumber);
      querySet.push(`phone_number = $${queryValues.length}`)
  }
  if (password){
      queryValues.push(await util.hash(password));
      querySet.push(`password = $${queryValues.length}`)
  }
  if (hasCarLicence){
      queryValues.push(hasCarLicence);
      querySet.push(`has_car_licence = $${queryValues.length}`)
  }
  if (hasMotorbikeLicence){
      queryValues.push(hasMotorbikeLicence);
      querySet.push(`has_motorbike_licence = $${queryValues.length}`)
  }
  if(queryValues.length > 0){
      queryValues.push(id);
      query += `${querySet.join(", ")} WHERE id = $${queryValues.length}`;
      return await SQLClient.query(query, queryValues);
  } else {
      throw new Error(`No field given`);
  }
}

export async function updatePerson(SQLClient, {id, firstName, lastName, email, phoneNumber, password, role, birthday, balance, hasCarLicence, hasMotorbikeLicence, referralCode}){
  let query = `UPDATE person SET `;
  const querySet = [];
  const queryValues = [];
  if (firstName) {
      queryValues.push(firstName);
      querySet.push(`first_name = $${queryValues.length}`);
  }
  if (lastName){
      queryValues.push(lastName);
      querySet.push(`last_name = $${queryValues.length}`)
  }
  if (email){
      queryValues.push(email);
      querySet.push(`email = $${queryValues.length}`)
  }
  if (phoneNumber){
      queryValues.push(phoneNumber);
      querySet.push(`phone_number = $${queryValues.length}`)
  }
  if (password){
      queryValues.push(await util.hash(password));
      querySet.push(`password = $${queryValues.length}`)
  }
  if (role){
    queryValues.push(role);
    querySet.push(`role = $${queryValues.length}`)
  }
  if (birthday){
      queryValues.push(birthday);
      querySet.push(`birthday = $${queryValues.length}`)
  }
  if (balance){
  queryValues.push(balance);
  querySet.push(`balance = $${queryValues.length}`)
  }
  if (hasCarLicence){
      queryValues.push(hasCarLicence);
      querySet.push(`has_car_licence = $${queryValues.length}`)
  }
  if (hasMotorbikeLicence){
      queryValues.push(hasMotorbikeLicence);
      querySet.push(`has_motorbike_licence = $${queryValues.length}`)
  }
  if(referralCode){
    queryValues.push(referralCode);
    querySet.push(`referral_code = $${queryValues.length}`)
  }
  if(queryValues.length > 0){
      queryValues.push(id);
      query += `${querySet.join(", ")} WHERE id = $${queryValues.length}`;
      return await SQLClient.query(query, queryValues);
  } else {
      throw new Error("No field given");
  }
}

export const updatePersonalBalance = async(SQLClient, {id, balance}) => {
  const {rows} =  await SQLClient.query(`UPDATE person SET balance = balance + $1 WHERE id = $2 RETURNING balance`, [balance, id]);
  return rows[0]?.balance;
}

export const deletePersons = async(SQLClient, {idList}) => {
  return await SQLClient.query(`DELETE FROM person WHERE id = ANY($1)`, [idList]);
}