import 'dotenv/config.js';
import jsonwebtoken from 'jsonwebtoken';

export const sign = (payload, options) => {
    return jsonwebtoken.sign(payload, process.env.JWTKEY, options);
};

export const verify = (jwt, options = {}) => {
  return jsonwebtoken.verify(jwt, process.env.JWTKEY, options);
};
